<?php 
  session_start();
  include "../koneksi.php";

  //-----------------------------
  $_SESSION['tgl'] = $_POST['tgl'] or die('DIRECT ACCESS IS PROHIBITED');
  $day = date('d');
  $month = date('m');
  $thn = date('Y');
  $tgl = $_SESSION['tgl'];
  //-----------------------------
  
  $u_ss = 1;
  $u_ss2 = 0;
  
	$sql2 = mysql_query("SELECT * FROM suratsuara WHERE left(waktu,10) = '$tgl'");
	$num_ss = mysql_num_rows($sql2);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Perhitungan</title>
    <meta name="description" content="Flat UI Kit Free is a Twitter Bootstrap Framework design and Theme, this responsive framework includes a PSD and HTML version."/>

    <meta name="viewport" content="width=1000, initial-scale=1.0, maximum-scale=1.0">

    <!-- Loading Bootstrap -->
    <!--<link href="css/bootstrap.css" rel="stylesheet">
    

    <!-- Loading Flat UI -->
    <!--<link href="css/flat-ui.css" rel="stylesheet">
    <link href="css/demo.css" rel="stylesheet">-->

    <link href="../css/metro.css" rel="stylesheet">
    <link href="../css/metro-icons.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/demo_table_jui.css">
    <link rel="stylesheet" type="text/css" href="../css/demo_table.css">
    <script src="../js/jquery.js"></script>
    <script src="../js/metro.js"></script>
    <script src="../js/jquery-2.0.3.min.js"></script>
    <script type="text/javascript" src="../js/jquery-1.4.js"></script>
    <script type="text/javascript" src="../js/jquery.fusioncharts.js"></script>
    <script type="text/javascript" src="../js/jquery.dataTables.js"></script>
    <link rel="shortcut icon" href="../img/favicon.ico">
    <!-- JAVASCRIPT -->
    <script type="text/javascript">
		$(document).ready(function () {
			function bukaSurat(){
				var strss = $("#txturut").val();
				if (strss != "")
				{ 
				  $("#result").html("<img src='../img/loading.gif'/>")
				  $.ajax({
					type: "POST",
					url: "setss.php",
					data:"q="+strss,
					success: function(data) {
					  $('#result').html(data);
					}
				  });
				}
			};
			function bukajml(){
				var strss = $("#txturut2").val();
				if (strss != "")
				{ 
				  $("#result2").html("<img src='../img/loading.gif'/>")
				  $.ajax({
					type: "POST",
					url: "setperolehan.php",
					data:"q="+strss,
					success: function(data) {
					  $('#result2').html(data);
					}
				  });
				}
			};
			$(".finish").click(function () {  
				var a = 1;
				var nourut = parseInt(document.getElementById("txturut").value);
				var nourut2 = document.getElementById("txturut");
				var c = nourut + a;
				var nourutjml = parseInt(document.getElementById("txturut2").value);
				var nourutjml2 = document.getElementById("txturut2");
				var d = nourutjml + a;
				nourutjml2.value = d;
				nourut2.value = c;
				bukaSurat();
				bukajml();
				var jmldt = parseInt(document.getElementById("txtjml").value);
				if(jmldt < c){
					$('#finish').hide();
				}
			});
			bukaSurat();
			bukajml();
		});
    </script>
    <!-- END OF JAVASCRIPT -->
  </head>
  <body>
    <div class="container" style="height:100%; padding-bottom:-10px;"> 
      <div class="headline2">
           <h1 class="head2" style="margin-top:10px; text-align:right;">
              Pemilu KM UTama <b style="color:#999999;">2016</b>
              <img src="../img/logo-pemilu.png" class="img-logo-small"/>
            </h1>
      </div>
    <!-- Menampilkan daftar surat suara yang berhasil masuk -->
        <div class="box-hitung-left">
            <div id="result2"></div>
        </div>
    <!-- Akhir dari tampilan surat suara masuk -->
        <div class="box-hitung-right">
			<input type="hidden" id="txturut" value="<?php echo $u_ss; ?>">
			<input type="hidden" id="txturut2" value="<?php echo $u_ss2; ?>">
			<input type="hidden" id="txtjml" value="<?php echo $num_ss; ?>">
            <h1 class="leader" align="center"></h1>
            <div class="box-kandidat2">
              
              <div id="result"></div>
			  <?php				
				if($num_ss != 0){
			  ?>
			  <a href="#" class="finish" style="float:right; margin-right:2px; margin-top:3px;" >
			  <button id="finish" class="button success" onclick="bukaSurat()" style="margin-top:-15px;">Submit</button>
			  </a>
				<?php } ?>
            </div>
        </div>
    </div>
  </body>
</html>