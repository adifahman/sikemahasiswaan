<?php 
	if(!isset($_POST['q'])){
		die('DIRECT ACCESS IS PROHIBITED');
	}
    include '../koneksi.php';
  //-----------------------------
  $day = date('d');
  $month = date('m');
  $thn = date('Y');
  //-----------------
    $a = $_POST['q'];
?>

<div class="box-header with-border">
  <h4>MPM</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_mpm=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='1' and masa_jabat='$thn' Order By no_urut");
		  while($row_mpm=mysql_fetch_array($sql_mpm)){
		  $mpm_nour=$row_mpm['no_urut'];
		  $mpm_foto=$row_mpm['foto'];
		  $mpm_npm=$row_mpm['npm'];
		  $mpm_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$mpm_npm'");
			$row=mysql_fetch_array($mpm_nama);
			$mpm_nm=$row['nama'];
			if($a==0){
				$mpm_jml=0;
			}else{
				$sql=mysql_query("select count(mpm) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and mpm='$i'");
				$rows=mysql_fetch_array($sql);
				$mpm_jml=$rows['jml'];
			}
	?>
	<tr>
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $mpm_nour; ?></td>
	  <td align="left" style="padding:4px 5px;"><?php echo $mpm_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $mpm_jml; ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>

<div class="box-header with-border">
  <h4>Presma</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_presma=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='2' and masa_jabat='$thn' Order By no_urut");
		  while($row_presma=mysql_fetch_array($sql_presma)){
		  $presma_nour=$row_presma['no_urut'];
		  $presma_foto=$row_presma['foto'];
		  $presma_npm=$row_presma['npm'];
		  $presma_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$presma_npm'");
			$row=mysql_fetch_array($presma_nama);
			$presma_nm=$row['nama'];
			
			if($a==0){
				$presma_jml=0;
			}else{
				$sql=mysql_query("select count(presma) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and presma='$i'");
				$rows=mysql_fetch_array($sql);
				$presma_jml=$rows['jml'];
			}
	?>
	<tr style="padding:1px;">
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $presma_nour; ?></td>
	  <!--<td width="75px" align="left" style="padding:2px 5px;"><img src="../foto/kandidat/presma/<?php echo $presma_foto.'.jpg'; ?>" style="width:40px; border-radius:50%;"></td>-->
	  <td align="left" style="padding:4px 5px;"><?php echo $presma_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $presma_jml; ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>
<?php 
	$sql_fe=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='3' and masa_jabat='$thn' Order By no_urut");
	$num_fe = mysql_num_rows($sql_fe);
	if($num_fe != 0){	
?>
<div class="box-header with-border">
  <h4>Senat FE</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_fe=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='3' and masa_jabat='$thn' Order By no_urut");
		  while($row_fe=mysql_fetch_array($sql_fe)){
		  $fe_nour=$row_fe['no_urut'];
		  $fe_foto=$row_fe['foto'];
		  $fe_npm=$row_fe['npm'];
		  $fe_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$fe_npm'");
			$row=mysql_fetch_array($fe_nama);
			$fe_nm=$row['nama'];
			
			if($a==0){
				$fe_jml=0;
			}else{
				$sql=mysql_query("select count(senat) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and senat='$i' and kd_senat='3'");
				$rows=mysql_fetch_array($sql);
				$fe_jml=$rows['jml'];
			}
	?>
	<tr style="padding:1px;">
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $fe_nour; ?></td>
	  <td align="left" style="padding:4px 5px;"><?php echo $fe_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $fe_jml ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>

<?php 
	}else{}
	$sql_fbm=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='4' and masa_jabat='$thn' Order By no_urut");
	$num_fbm = mysql_num_rows($sql_fbm);
	if($num_fbm != 0){	
?>
<div class="box-header with-border">
  <h4>Senat FBM</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_fbm=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='4' and masa_jabat='$thn' Order By no_urut");
		  while($row_fbm=mysql_fetch_array($sql_fbm)){
		  $fbm_nour=$row_fbm['no_urut'];
		  $fbm_foto=$row_fbm['foto'];
		  $fbm_npm=$row_fbm['npm'];
		  $fbm_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$fbm_npm'");
			$row=mysql_fetch_array($fbm_nama);
			$fbm_nm=$row['nama'];
			
			if($a==0){
				$fbm_jml=0;
			}else{
				$sql=mysql_query("select count(senat) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and senat='$i' and kd_senat='4'");
				$rows=mysql_fetch_array($sql);
				$fbm_jml=$rows['jml'];
			}
	?>
	<tr style="padding:1px;">
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $fbm_nour; ?></td>
	  <td align="left" style="padding:4px 5px;"><?php echo $fbm_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $fbm_jml; ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>

<?php 
	}else{}
	$sql_teknik=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='5' and masa_jabat='$thn' Order By no_urut");
	$num_teknik = mysql_num_rows($sql_teknik);
	if($num_teknik != 0){	
?>
<div class="box-header with-border">
  <h4>Senat Teknik</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_teknik=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='5' and masa_jabat='$thn' Order By no_urut");
		  while($row_teknik=mysql_fetch_array($sql_teknik)){
		  $teknik_nour=$row_teknik['no_urut'];
		  $teknik_foto=$row_teknik['foto'];
		  $teknik_npm=$row_teknik['npm'];
		  $teknik_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$teknik_npm'");
			$row=mysql_fetch_array($teknik_nama);
			$teknik_nm=$row['nama'];
			if($a==0){
				$teknik_jml=0;
			}else{
				$sql=mysql_query("select count(senat) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and senat='$i' and kd_senat='5'");
				$rows=mysql_fetch_array($sql);
				$teknik_jml=$rows['jml'];
			}
	?>
	<tr style="padding:1px;">
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $teknik_nour; ?></td>
	  <td align="left" style="padding:4px 5px;"><?php echo $teknik_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $teknik_jml; ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>

<?php 
	}else{}
	$sql_bhs=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='6' and masa_jabat='$thn' Order By no_urut");
	$num_bhs = mysql_num_rows($sql_bhs);
	if($num_bhs != 0){	
?>
<div class="box-header with-border">
  <h4>Senat Bahasa</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_bahasa=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='6' and masa_jabat='$thn' Order By no_urut");
		  while($row_bahasa=mysql_fetch_array($sql_bahasa)){
		  $bahasa_nour=$row_bahasa['no_urut'];
		  $bahasa_foto=$row_bahasa['foto'];
		  $bahasa_npm=$row_bahasa['npm'];
		  $bahasa_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$bahasa_npm'");
			$row=mysql_fetch_array($bahasa_nama);
			$bahasa_nm=$row['nama'];
			if($a==0){
				$bahasa_jml=0;
			}else{
				$sql=mysql_query("select count(senat) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and senat='$i' and kd_senat='6'");
				$rows=mysql_fetch_array($sql);
				$bahasa_jml=$rows['jml'];
			}
	?>
	<tr style="padding:1px;">
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $bahasa_nour; ?></td>
	  <td align="left" style="padding:4px 5px;"><?php echo $bahasa_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $bahasa; ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>
<?php
	}else{}
	$sql_dkv=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='7' and masa_jabat='$thn' Order By no_urut");
	$num_dkv = mysql_num_rows($sql_dkv);
	if($num_dkv != 0){	
?>
<div class="box-header with-border">
  <h4>Senat DKV</h4>
</div>
<div class="box-body">
  <table class="table table-bordered">
	  <?php
		 $i = 1;
		  $sql_dkv=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='7' and masa_jabat='$thn' Order By no_urut");
		  while($row_dkv=mysql_fetch_array($sql_dkv)){
		  $dkv_nour=$row_dkv['no_urut'];
		  $dkv_foto=$row_dkv['foto'];
		  $dkv_npm=$row_dkv['npm'];
		  $dkv_nama=mysql_query("SELECT * FROM mahasiswa WHERE npm='$dkv_npm'");
			$row=mysql_fetch_array($dkv_nama);
			$dkv_nm=$row['nama'];
			if($a==0){
				$dkv_jml=0;
			}else{
				$sql=mysql_query("select count(senat) AS jml from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r order by waktu ASC) AS v WHERE no Between 1 and '$a' and senat='$i' and kd_senat='7'");
				$rows=mysql_fetch_array($sql);
				$dkv_jml=$rows['jml'];
			}
	?>
	<tr style="padding:1px;">
	  <td width="5px;" height="20px" style="padding:2px 5px;"><?php echo $dkv_nour; ?></td>
	  <td align="left" style="padding:4px 5px;"><?php echo $dkv_nm; ?></td>
	  <td width="15px" style="padding:2px 5px;"><span class="badge bg-blue"><?php echo $dkv_jml; ?></span></td>
	</tr>
	
	<?php  
	
		$i++;
		}
	?>
  </table>
</div>
<?php
	}else{}
?>
