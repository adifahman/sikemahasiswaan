<?php 
	session_start();
	if(!isset($_POST['q'])){
		die('DIRECT ACCESS IS PROHIBITED');
	}
    include '../koneksi.php';
  //-----------------------------
  $day = date('d');
  $month = date('m');
  $thn = date('Y');
  $tgl = $_SESSION['tgl'];
  //-----------------
    $a = $_POST['q'];
	$sql=mysql_query("select * from (select @row:= @row+1 AS 'no',suratsuara.* FROM suratsuara,(select @row:=0) AS r where left(waktu,10) = '$tgl' order by right(id_ss,4) ASC) AS v WHERE no = '$a'");
	$rownya=mysql_fetch_array($sql);
	$sql2 = mysql_query("select * from suratsuara WHERE left(waktu,10) = '$tgl'");
	$num_ss = mysql_num_rows($sql2);
	$q=$rownya['id_ss'];
	
	if($num_ss == 0){ ?>
		<div class="notif-submit">
			  <h1 class="leader">Maaf</h1>
			  <h2 class="header">Data Tidak ditemukan</h2>
		  </div>
	<?php }else if($a > $num_ss){ ?>
		 <div class="notif-submit">
			  <h1 class="header">Surat Suara telah habis</h1>
		  </div>
	<?php }
	else{
	?>
	<table class="table">
		<tr>
			<td width="150px;">No. Surat Suara</td>
			<td width="10px;"> : </td>
			<td width="500px"><?php echo $q; ?></td>
			<td align="right"><?php echo "Surat suara ke-$a dari $num_ss Surat suara" ?></td>
		</tr>
	</table>
	<div style="margin-top:-15px;" class="wizard" 
                      data-role="wizard" 
                      data-buttons='{"next":{ "show":"true", "cls": "primary", "group": "right"}, 
                          "prior": { "show":"true","title": "Prev", "cls": "danger", "group": "right"}}'
                      data-stepper-clickable="true">
                  <div class="steps">
                      <div class="step">
                        <div class="judul-kandidat">
                          MPM (Majelis Permusyawaratan Mahasiswa)
                        </div>
                          <div class="box-kandidat-foto">
                          <?php
                              $i = 1;
                              $sql_forum=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='1' and masa_jabat='$thn' Order By no_urut ASC");
                              $sql_forum2=mysql_query("SELECT * FROM suratsuara WHERE id_ss='$q'");
                              $rows2=mysql_fetch_array($sql_forum2);
                              while($rows=mysql_fetch_array($sql_forum)){ // Start looping table row
                                  $mpm_npm=$rows['npm'];
                                  $mpm_foto=$rows['foto'];
                                  if($mpm_foto == ''){
                                    $mpm_foto='foto.jpg';
                                  }else{
                                    $mpm_foto=$rows['foto'];
                                  }
                                  $q_nmKand=mysql_query("SELECT * FROM mahasiswa WHERE npm='$mpm_npm'");
                                  $row=mysql_fetch_array($q_nmKand);
                                  $mpm_nama=$row['nama'];
                                  $pil_mpm=$rows2['mpm'];
                                  if($i==$pil_mpm) {
                          ?>
                            <div class="box-isi-kandidat">
                              <div class="box-data-kandidat" align="right">
                                  <label class="input-control radio small-check">
                                      <input type="radio" name="mpm" CHECKED/>
                                      <span class="check"></span>
                                      <span class="caption">
                                        <img src="../foto/kandidat/mpm/<?php echo $mpm_foto.'.png'; ?>" class="ft-kandidat-on">
                                        <div class="isi-kandidat-profil">
                                            <h4><?php echo $mpm_nama; ?></h4>
                                        </div>
                                      </span>
                                  </label>
                              </div>
                            </div>
                            <?php
                            } else {
                            ?>
                            <div class="box-isi-kandidat">
                              <div class="box-data-kandidat" align="right">
                                  <label class="input-control radio small-check">
                                      <input type="radio" name="mpm" disabled />
                                      <span class="check"></span>
                                      <span class="caption">
                                        <img src="../foto/kandidat/mpm/<?php echo $mpm_foto.'.png'; ?>" class="ft-kandidat-off">
                                        <div class="isi-kandidat-profil">
                                            <h4><?php echo $mpm_nama; ?></h4>
                                        </div>
                                      </span>
                                  </label>
                              </div>
                            </div>
                            <?php  
                            }
                                $i++;
                                }
                            ?>
                          </div>
                      </div>
                      <div class="step">
                        <div class="judul-kandidat">
                          Presma (Presiden Mahasiswa)
                        </div>
                        <div class="box-kandidat-foto" align="center">
                           <?php
                              $i = 1;
                              $sql_forum=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='2' and masa_jabat='$thn' Order By no_urut ASC");
                              $sql_forum2=mysql_query("SELECT * FROM suratsuara WHERE id_ss='$q'");
                              $rows2=mysql_fetch_array($sql_forum2);
                              while($rows=mysql_fetch_array($sql_forum)){ // Start looping table row
                                  $presma_npm=$rows['npm'];
                                  $presma_foto=$rows['foto'];
                                  if($presma_foto == ''){
                                    $presma_foto='foto.jpg';
                                  }else{
                                    $presma_foto=$rows['foto'];
                                  }
                                  $q_nmKand2=mysql_query("SELECT * FROM mahasiswa WHERE npm='$presma_npm'");
                                  $row2=mysql_fetch_array($q_nmKand2);
                                  $presma_nama=$row2['nama'];
                                  $pil_mpm=$rows2['presma'];
                                  if($i==$pil_mpm) {
                          ?>
                              <div class="box-isi-kandidat">
                                <div class="box-data-kandidat" align="right">
                                    <label class="input-control radio small-check">
                                        <input type="radio" name="presma" CHECKED />
                                        <span class="check"></span>
                                        <span class="caption">
                                          <img src="../foto/kandidat/presma/<?php echo $presma_foto.'.png'; ?>" class="ft-kandidat-on">
                                          <div class="isi-kandidat-profil">
                                              <h4><?php echo $presma_nama; ?></h4>
                                          </div>
                                        </span>
                                    </label>
                                </div>
                              </div>
                              <?php
                              } else {
                              ?>  
                              <div class="box-isi-kandidat">
                                <div class="box-data-kandidat" align="right">
                                    <label class="input-control radio small-check">
                                        <input type="radio" name="presma" disabled />
                                        <span class="check"></span>
                                        <span class="caption">
                                          <img src="../foto/kandidat/presma/<?php echo $presma_foto.'.png'; ?>" class="ft-kandidat-off">
                                          <div class="isi-kandidat-profil">
                                              <h4><?php echo $presma_nama; ?></h4>
                                          </div>
                                        </span>
                                    </label>
                                </div>
                              </div>
                              <?php }
                                  $i++;
                                  }
                              ?>
                        </div>
                      </div>
                      <div style="clear:left;">
                      <div class="step">
                        <div class="judul-kandidat">SENAT 
                          <?php
                          $sql_forum2=mysql_query("SELECT * FROM suratsuara WHERE id_ss='$q'");
                          $rows2=mysql_fetch_array($sql_forum2);
                          $jurusan=substr($q, 4,-6);
                            if($jurusan == '01' || $jurusan == '03'){
                                echo "FE";
                                $senat = "3";
                            }
                            else if($jurusan == '02' || $jurusan == '04'){
                                echo "FBM";
                                $senat = "4";
                            }
                            else if($jurusan == '05' || $jurusan == '06' || $jurusan == '11'){
                                echo "TEKNIK";
                                $senat = "5";
                            }
                            else if($jurusan == '07' || $jurusan == '08'){
                                echo "BAHASA";
                                $senat = "6";
                            }
                            else if($jurusan == '09' || $jurusan == '10'){
                                echo "DKV";
                                $senat = "7";
                            }else{
                              echo "$jurusan";
                            }
                           ?>
                        </div> 
                           <div class="box-kandidat-foto">
                                 <?php
                                    $i = 1;
                                    $sql_forum=mysql_query("SELECT * FROM kandidat WHERE kd_organisasi='$senat' and masa_jabat='$thn' Order By no_urut ASC");
                                    $cek=mysql_num_rows($sql_forum);
                                    if ($cek <=  0) { ?>
                                        <div class="notify">
                                            <span class="notify-icon mif-notification"></span>
                                            <span class="notify-title">Maaf</span>
                                            <span class="notify-text">Tidak ada kandidat untuk senat fakultas anda</span>
                                        </div>
                                    <?php } else{
                                    while($rows=mysql_fetch_array($sql_forum)){ // Start looping table row
                                        $senat_npm=$rows['npm'];
                                        $senat_foto=$rows['foto'];
                                        if($senat_foto == ''){
                                          $senat_foto='foto.jpg';
                                        }else{
                                          $senat_foto=$rows['foto'];
                                        }
                                        $q_nmKand=mysql_query("SELECT * FROM mahasiswa WHERE npm='$senat_npm'");
                                        $row=mysql_fetch_array($q_nmKand);
                                        $senat_nama=$row['nama'];
                                        $pil_senat=$rows2['senat'];
                                        if($i==$pil_senat) {
                                ?>
                                  <div class="box-isi-kandidat">
                                    <div class="box-data-kandidat" align="right">
                                        <label class="input-control radio small-check">
                                            <input type="radio" name="senat" CHECKED />
                                            <span class="check"></span>
                                            <span class="caption">
                                              <img src="../foto/kandidat/senat/<?php echo $senat_foto.'.png'; ?>" class="ft-kandidat-on">
                                              <div class="isi-kandidat-profil">
                                                  <h4><?php echo $senat_nama; ?></h4>
                                              </div>
                                            </span>
                                        </label>
                                    </div>
                                  </div>
                                  <?php
                                } else {
                                  ?>
                                  <div class="box-isi-kandidat">
                                    <div class="box-data-kandidat" align="right">
                                        <label class="input-control radio small-check">
                                            <input type="radio" name="senat" disabled />
                                            <span class="check"></span>
                                            <span class="caption">
                                              <img src="../foto/kandidat/senat/<?php echo $senat_foto.'.png'; ?>" class="ft-kandidat-off">
                                              <div class="isi-kandidat-profil">
                                                  <h4><?php echo $senat_nama; ?></h4>
                                              </div>
                                            </span>
                                        </label>
                                    </div>
                                  </div>
                                  <?php
                                }
                                      $i++;
                                      } }
                                  ?>
                            </div>
                      </div>
                      <div style="clear:left;"></div>
              </div>
              </div>
          </div>
	<?php } ?>
